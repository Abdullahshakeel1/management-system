import React, { createContext, useContext, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

// Create Context
const AuthContext = createContext();

// Create Provider Component
export const AuthProvider = ({ children }) => {
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const navigate = useNavigate();

    useEffect(() => {
        // Check authentication status (e.g., from local storage or API)
        const checkAuth = () => {
            const authToken = localStorage.getItem('authToken'); // Replace with your auth logic
            setIsAuthenticated(!!authToken);
        };

        checkAuth();
    }, []);

    const login = () => {
        // Handle login logic here
        setIsAuthenticated(true);
        navigate('/');
    };

    const logout = () => {
        // Handle logout logic here
        setIsAuthenticated(false);
        localStorage.removeItem('authToken');
        navigate('/login');
    };

    return (
        <AuthContext.Provider value={{ isAuthenticated, login, logout }}>
            {children}
        </AuthContext.Provider>
    );
};

// Custom hook to use auth context
export const useAuth = () => useContext(AuthContext);
