import React, { useState } from 'react';
import AddUser from './addUser';
import UserList from './userList';
import { Navigate, useNavigate } from 'react-router-dom';

const User = () => {
  const Navigate = useNavigate()
  const [view, setView] = useState(null);

  const handleViewChange = (viewType) => {
    setView(viewType);
  };
  const handleLogout = () => {
    try {
      localStorage.clear(); // Clear all localStorage data
      Navigate('/login'); // Navigate to the login page
    } catch (error) {
      console.error('Error logging out:', error);
      // Handle any potential errors here, such as displaying an error message to the user
    }
  };

  return (
<>

<div className="flex flex-wrap items-center cursor-pointer border-t border-gray-300 px-4 py-4">
    <div className="ml-4">
        <button
            onClick={handleLogout}
            className="bg-[#7f5aa4] text-white px-4 py-2 rounded-md hover:bg-[black] hover:text-white"
        >
            <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 1024 1024"><path fill="#ffff" d="M868 732h-70.3c-4.8 0-9.3 2.1-12.3 5.8c-7 8.5-14.5 16.7-22.4 24.5a353.8 353.8 0 0 1-112.7 75.9A352.8 352.8 0 0 1 512.4 866c-47.9 0-94.3-9.4-137.9-27.8a353.8 353.8 0 0 1-112.7-75.9a353.3 353.3 0 0 1-76-112.5C167.3 606.2 158 559.9 158 512s9.4-94.2 27.8-137.8c17.8-42.1 43.4-80 76-112.5s70.5-58.1 112.7-75.9c43.6-18.4 90-27.8 137.9-27.8s94.3 9.3 137.9 27.8c42.2 17.8 80.1 43.4 112.7 75.9c7.9 7.9 15.3 16.1 22.4 24.5c3 3.7 7.6 5.8 12.3 5.8H868c6.3 0 10.2-7 6.7-12.3C798 160.5 663.8 81.6 511.3 82C271.7 82.6 79.6 277.1 82 516.4C84.4 751.9 276.2 942 512.4 942c152.1 0 285.7-78.8 362.3-197.7c3.4-5.3-.4-12.3-6.7-12.3m88.9-226.3L815 393.7c-5.3-4.2-13-.4-13 6.3v76H488c-4.4 0-8 3.6-8 8v56c0 4.4 3.6 8 8 8h314v76c0 6.7 7.8 10.5 13 6.3l141.9-112a8 8 0 0 0 0-12.6" /></svg>
        </button>
    </div>
</div>
    <div className="flex flex-col items-center mt-8">
      <div className="flex gap-10 mb-8">
        <button
          className='h-10 w-32 bg-[#7f5aa4] text-white px-4 rounded-full hover:bg-black hover:text-white'
          onClick={() => handleViewChange('addUser')}
        >
          Add User
        </button>
        <button
          className='h-10 w-32 bg-[#7f5aa4] text-white px-4 rounded-full hover:bg-black hover:text-white'
          onClick={() => handleViewChange('userList')}
        >
          User List
        </button>
      </div>

      {view === 'addUser' && <AddUser />}
      {view === 'userList' && <UserList />}
    </div>
</>
  );
};

export default User;
