import React from 'react'

const NotFound = () => {
  return (
    <div className=' h-screen w-full text-[#7f5aa4] bg-[#7f5aa4] text-3xl flex items-center justify-center font-bold '>

      <div className='bg-gray-100 p-20 rounded-lg '> Page NotFound  <div className='text-center pt-5'>🥴🥴</div></div>
     
    </div>
  )
}

export default NotFound