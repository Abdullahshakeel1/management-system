import React, { useState } from 'react';
import Sidebar from './components/sidebar';
import './index.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Home from './components/Home';

import Login from './components/Login';
import Error from './components/Error';
import { FaBars } from 'react-icons/fa';
import NotFound from './components/NotFound';

function App() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route
          path="/*"
          element={
            <div className="flex h-full min-h-screen">
              {isSidebarOpen && (
                <div className="fixed z-20 md:z-0 md:relative">
                  <Sidebar />
                </div>
              )}
              <div className="flex-1 md:ml-[250px]">
                <div className="p-4 md:hidden">
                  <button
                    onClick={toggleSidebar}
                    className="text-gray-500 focus:outline-none focus:text-gray-700"
                  >
                    <FaBars size={24} />
                  </button>
                </div>
                <Routes>
                  <Route
                    path="/"
                    element={
                        <Home />
                    }
                  />
                  <Route
                    path="/*"
                    element={
                        <NotFound />
                    }
               />
                </Routes>
              </div>
            </div>
          }
        />
        <Route path="*" element={<Error />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
